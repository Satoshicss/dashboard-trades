
const trades = [
    { date: "2025-05-19", crypto: "BNB", entry: 644, exit: 662 },
    { date: "2025-05-20", crypto: "ORDI", entry: 34.5, exit: 37.8 }
];

const tbody = document.getElementById("tradeData");
trades.forEach(t => {
    const profit = ((t.exit - t.entry) / t.entry * 100).toFixed(2) + "%";
    tbody.innerHTML += `<tr>
        <td>${t.date}</td>
        <td>${t.crypto}</td>
        <td>${t.entry}</td>
        <td>${t.exit}</td>
        <td>${profit}</td>
    </tr>`;
});

const ctx = document.getElementById("profitChart").getContext("2d");
new Chart(ctx, {
    type: "line",
    data: {
        labels: trades.map(t => t.date),
        datasets: [{
            label: "Profit (%)",
            data: trades.map(t => ((t.exit - t.entry) / t.entry * 100).toFixed(2)),
            borderColor: "#00ff88",
            fill: false,
            tension: 0.1
        }]
    }
});
